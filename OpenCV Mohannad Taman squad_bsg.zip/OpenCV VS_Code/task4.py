from ctypes.wintypes import RGB
import cv2
import numpy as np
global n
global m
def mouseev(event , x , y , flags , params ):
    global n
    global m
    if event == cv2.EVENT_LBUTTONDBLCLK:
        n=x
        m=y
        cv2.circle(img , (x , y) , 20 , (255 , 0 , 0) , 2)
        cv2.imshow("image" , img)
    elif event == cv2.EVENT_RBUTTONDOWN:
        cv2.circle(img , (n , m) , 20 , (0 , 0 , 0) , 2)
        cv2.imshow("image" , img)
    elif event == cv2.EVENT_RBUTTONDBLCLK:
        cv2.circle(img , (n , m) , 20 , (0 , 0 , 0) , 2)
        cv2.decolor(img , RGB(0 , 0 , 0))
img = np.zeros((500 , 500 , 3) , np.uint8)
cv2.imshow("image" , img)
cv2.setMouseCallback("image" , mouseev)
cv2.waitKey(0)