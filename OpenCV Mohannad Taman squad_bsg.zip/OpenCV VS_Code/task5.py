
import cv2
import numpy as np
i = 0
tuples = np.zeros((4,2) , np.int0 )
def mouseevent(event , x , y , flags , params ):
    global i
    global tuples
    if event == cv2.EVENT_LBUTTONDBLCLK:
        tuples[i] = (x,y)
        i+=1
img=cv2.imread("js.jfif")
while True:
    for x in range(0 , 4):
        cv2.circle(img , (tuples[x,0] , tuples[x,1]) , 5 , (255 , 0 , 0) , cv2.FILLED)
    if i == 4:
        width,height=640,480
        p1=np.float32([tuples[0],tuples[1],tuples[2],tuples[3]])
        p2 = np.float32([[0,0],[width,0],[0,height],[width,height]])
        matrix=cv2.getPerspectiveTransform(p1,p2)
        wrapped=cv2.warpPerspective(img,matrix,(width,height))
        cv2.imshow("imagew",wrapped)
    cv2.imshow("image",img)
    cv2.waitKey(1)
    cv2.setMouseCallback("image" , mouseevent)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break 

