import cv2
import numpy as np
def stackImages(scale,imgArray):
    rows = len(imgArray)
    cols = len(imgArray[0])
    rowsAvailable = isinstance(imgArray[0], list)
    width = imgArray[0][0].shape[1]
    height = imgArray[0][0].shape[0]
    if rowsAvailable:
        for x in range ( 0, rows):
            for y in range(0, cols):
                if imgArray[x][y].shape[:2] == imgArray[0][0].shape [:2]:
                    imgArray[x][y] = cv2.resize(imgArray[x][y], (0, 0), None, scale, scale)
                else:
                    imgArray[x][y] = cv2.resize(imgArray[x][y], (imgArray[0][0].shape[1], imgArray[0][0].shape[0]), None, scale, scale)
                if len(imgArray[x][y].shape) == 2: imgArray[x][y]= cv2.cvtColor( imgArray[x][y], cv2.COLOR_GRAY2BGR)
        imageBlank = np.zeros((height, width, 3), np.uint8)
        hor = [imageBlank]*rows
        hor_con = [imageBlank]*rows
        for x in range(0, rows):
            hor[x] = np.hstack(imgArray[x])
        ver = np.vstack(hor)
    else:
        for x in range(0, rows):
            if imgArray[x].shape[:2] == imgArray[0].shape[:2]:
                imgArray[x] = cv2.resize(imgArray[x], (0, 0), None, scale, scale)
            else:
                imgArray[x] = cv2.resize(imgArray[x], (imgArray[0].shape[1], imgArray[0].shape[0]), None,scale, scale)
            if len(imgArray[x].shape) == 2: imgArray[x] = cv2.cvtColor(imgArray[x], cv2.COLOR_GRAY2BGR)
        hor= np.hstack(imgArray)
        ver = hor
    return ver
img1 = np.zeros((50, 50 , 3) , np.uint8)
img1[:] = 255 , 0 ,0
img2 = np.zeros((50, 50 , 3) , np.uint8)
img2[:] = 170 , 74 , 68
img3 = np.zeros((50, 50 , 3) , np.uint8)
img3[:] = 69 , 75 , 27
img4 = np.zeros((50, 50 , 3) , np.uint8)
img4[:] = 0 , 0 , 0
# cv2.imshow("blue image" , img1)
# cv2.imshow("purple image" , img2)
# cv2.imshow("green image" , img3)
attached = stackImages(1 , ([img1 , img3] , [img2 , img4]  ))
attached = cv2.resize(attached , (200 , 200))
cv2.imshow("Attached image" , attached)

cv2.waitKey(0)