import cv2
from cv2 import rotate
from cv2 import destroyAllWindows
import numpy as np
cam = cv2.VideoCapture(0)
cam.set(3 , 640) # 3 is id for width
cam.set(4 , 480) # 4 id if for height
while True:
    success , img = cam.read()
    cv2.imshow("Webcam" , img)
    if cv2.waitKey(1) & 0xFF ==ord('r'):
        while True:
            success , img = cam.read()
            imgrotated = rotate(img , cv2.ROTATE_90_CLOCKWISE)
           # cv2.destroyWindow("Webcam")
            cv2.imshow("Webcam-rotated" , imgrotated)
            if cv2.waitKey(1) & 0xFF ==ord('q'):
                break
    elif cv2.waitKey(1) & 0xFF ==ord('q'):
        break
    elif cv2.waitKey(1) & 0xFF==ord("c"):
            cv2.imwrite("frame.png" , img)
    elif cv2.waitKey(1) & 0xFF==ord("g"):
        while True:
            sucsess , img = cam.read()
            imggray = cv2.cvtColor(img , cv2.COLOR_BGR2GRAY)
            cv2.imshow("grayscale" , imggray)
            if cv2.waitKey(1) & 0xFF ==ord('q'):
                break 
    elif cv2.waitKey(1) & 0xFF==ord("h"):
        while True:
            sucsess , img = cam.read()
            imghsv = cv2.cvtColor(img,cv2.COLOR_BGR2HSV)
            cv2.imshow("HSV",imghsv)
            if cv2.waitKey(1) & 0xFF ==ord('q'):
                break 
    elif cv2.waitKey(1) & 0xFF==ord("z"):
        while True:
            sucsess , img = cam.read()
            cv2.imshow("original",img)
            if cv2.waitKey(1) & 0xFF ==ord('q'):
                break 
    elif cv2.waitKey(1) & 0xFF==ord("x"):
        while True:
            sucsess , img = cam.read()
            imgrotated = rotate(img , cv2.ROTATE_90_CLOCKWISE)
            imghsv = cv2.cvtColor(img,cv2.COLOR_BGR2HSV)
            imggray = cv2.cvtColor(img , cv2.COLOR_BGR2GRAY)
            cv2.imshow("HSV",imghsv)
            cv2.imshow("grayscale" , imggray)
            cv2.imshow("Webcam-rotated" , imgrotated)
            cv2.imshow("original",img)
            if cv2.waitKey(1) & 0xFF ==ord('q'):
                break 
    elif cv2.waitKey(1) & 0xFF==ord("s"):
        while True:
            sucsess , img = cam.read()
            size=(640,480)
            result = cv2.VideoWriter('saved.avi', cv2.VideoWriter_fourcc(*'MJPG'),10, size)
            if cv2.waitKey(1) & 0xFF ==ord('q'):
                break 
    
